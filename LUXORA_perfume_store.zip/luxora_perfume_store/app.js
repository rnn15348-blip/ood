const products=[
 {id:1,name:'Bvlgari Jasmin Noir L’Essence',short:'Jasmin Noir L’Essence',type:'female',typeFa:'زنانه',price:99000,img:'assets/bvlgari.jpg',desc:'رایحه‌ای مجلل با حال‌وهوای گل‌های سفید، گرم و اغواگر؛ انتخابی برای شب‌های خاص.'},
 {id:2,name:'Versace Bright Crystal',short:'Bright Crystal',type:'female',typeFa:'زنانه',price:99000,img:'assets/versace.jpg',desc:'رایحه‌ای شفاف، لطیف و درخشان با حس میوه‌ای و گل‌فام؛ ظریف و روزمره.'},
 {id:3,name:'Paco Rabanne 1 Million',short:'1 Million',type:'male',typeFa:'مردانه',price:99000,img:'assets/one-million.jpg',desc:'امضای گرم و جسورانه با حال‌وهوای لوکس، شیرین و ادویه‌ای؛ مناسب استایل‌های چشمگیر.'},
 {id:4,name:'Adidas Victory League',short:'Victory League',type:'male',typeFa:'مردانه',price:99000,img:'assets/adidas.jpg',desc:'رایحه‌ای اسپرت و پرانرژی برای استفاده روزانه؛ ساده، تمیز و جوان‌پسند.'},
 {id:5,name:'Dolce & Gabbana Intenso',short:'Intenso',type:'male',typeFa:'مردانه',price:99000,img:'assets/intenso.jpg',desc:'رایحه‌ای عمیق و گرم با شخصیت چوبی و شرقی؛ مناسب شب و موقعیت‌های رسمی.'}
];
let cart=JSON.parse(localStorage.getItem('luxora-cart')||'[]');
const grid=document.getElementById('productGrid');
const nf=new Intl.NumberFormat('fa-IR');
function renderProducts(filter='all'){
 grid.innerHTML=products.filter(p=>filter==='all'||p.type===filter).map(p=>`<article class="product" data-id="${p.id}"><button class="details-btn" onclick="showProduct(${p.id})">جزئیات</button><div class="product-img"><img src="${p.img}" alt="${p.name}"></div><div class="product-body"><div class="tag">${p.typeFa} · LUXORA</div><h4>${p.short}</h4><p>${p.desc}</p><div class="price-row"><span class="price">${nf.format(p.price)} تومان</span><button class="add-btn" onclick="addToCart(${p.id})">+</button></div></div></article>`).join('');
}
function save(){localStorage.setItem('luxora-cart',JSON.stringify(cart));renderCart();}
function addToCart(id){const found=cart.find(x=>x.id===id);found?found.qty++:cart.push({id,qty:1});save();toast('به سبد خرید اضافه شد ✦');}
function changeQty(id,delta){const x=cart.find(i=>i.id===id);if(!x)return;x.qty+=delta;if(x.qty<=0)cart=cart.filter(i=>i.id!==id);save();}
function renderCart(){const box=document.getElementById('cartItems');let total=0,count=0;if(!cart.length){box.innerHTML='<div style="text-align:center;color:#666;padding:60px 10px">سبد خرید شما خالی است.</div>'}else{box.innerHTML=cart.map(i=>{const p=products.find(x=>x.id===i.id);total+=p.price*i.qty;count+=i.qty;return `<div class="cart-line"><img src="${p.img}" alt=""><div style="flex:1"><strong>${p.short}</strong><small>${nf.format(p.price)} تومان</small><div class="qty"><button onclick="changeQty(${p.id},-1)">−</button><span>${i.qty}</span><button onclick="changeQty(${p.id},1)">+</button></div></div></div>`}).join('')}document.getElementById('cartCount').textContent=count;document.getElementById('cartTotal').textContent=nf.format(total)+' تومان';}
function showProduct(id){const p=products.find(x=>x.id===id);document.getElementById('modalContent').innerHTML=`<div class="modal-product"><img src="${p.img}" alt="${p.name}"><div><div class="eyebrow">${p.typeFa} · SIGNATURE SCENT</div><h2>${p.name}</h2><p>${p.desc}</p><div class="price" style="font-size:22px;margin:22px 0">${nf.format(p.price)} تومان</div><button class="gold-btn" onclick="addToCart(${p.id});closeModal()">افزودن به سبد خرید</button></div></div>`;document.getElementById('productModal').classList.add('show')}
function closeModal(){document.getElementById('productModal').classList.remove('show')}
function toast(msg){const t=document.getElementById('toast');t.textContent=msg;t.classList.add('show');clearTimeout(window.__toast);window.__toast=setTimeout(()=>t.classList.remove('show'),1800)}
function toggleCart(open){document.getElementById('cartDrawer').classList.toggle('open',open);document.getElementById('backdrop').classList.toggle('show',open)}
function updateClock(){document.getElementById('clock').textContent=new Date().toLocaleTimeString('fa-IR',{hour:'2-digit',minute:'2-digit',second:'2-digit'})}
renderProducts();renderCart();updateClock();setInterval(updateClock,1000);
document.querySelectorAll('.filter').forEach(btn=>btn.addEventListener('click',()=>{document.querySelectorAll('.filter').forEach(b=>b.classList.remove('active'));btn.classList.add('active');renderProducts(btn.dataset.filter)}));
document.getElementById('cartBtn').onclick=()=>toggleCart(true);document.getElementById('closeCart').onclick=()=>toggleCart(false);document.getElementById('backdrop').onclick=()=>toggleCart(false);document.getElementById('modalClose').onclick=closeModal;document.getElementById('productModal').addEventListener('click',e=>{if(e.target.id==='productModal')closeModal()});
document.getElementById('menuBtn').onclick=()=>document.getElementById('navLinks').classList.toggle('open');
document.getElementById('surpriseBtn').onclick=()=>{const p=products[Math.floor(Math.random()*products.length)];showProduct(p.id)};
document.getElementById('checkoutBtn').onclick=()=>{if(!cart.length){toast('ابتدا یک محصول به سبد اضافه کنید');return}toast('دموی ثبت سفارش آماده است — اطلاعات پرداخت را بعداً اضافه کنید.');};
window.addToCart=addToCart;window.changeQty=changeQty;window.showProduct=showProduct;window.closeModal=closeModal;
setTimeout(()=>document.body.classList.add('ready'),3200);
